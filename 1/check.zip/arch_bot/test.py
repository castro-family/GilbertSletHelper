s = "asdasdas:sadasdasd:sdaasdasd:sdfsdfsdfsdfsdf"
reslt = s.split(':')
print(reslt)
