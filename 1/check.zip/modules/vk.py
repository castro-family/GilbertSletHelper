import nextcord
from nextcord import Interaction, SlashOption
from nextcord.ext import commands
import asyncio
import time as pyTime
from vkbottle.bot import Bot, Message
from vkbottle import API
from vkbottle import GroupEventType, GroupTypes, Keyboard, Text, KeyboardButtonColor, Callback
from vkbottle.modules import json as vkjs
import re
import os
import json
import random
# from loguru import logger
# logger.disable("vkbottle")
cfg = json.load(open(f"./settings.json"))

user = API(token=cfg["account"]["token"])
vkserver = Bot(token=cfg["bot_vk"]["token"])

# regax = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
# regax2 = "11"
# if regax2 in regax:
#     print(regax2)

class Vk(commands.Cog):
    def __init__(self, bot:commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(2)
        async with self.bot.db.cursor() as cursor:
            await cursor.execute("CREATE TABLE IF NOT EXISTS users (vkid INTEGER, nick TEXT, status INTEGER, fraction INTEGER, vig INTEGER, fed_vig INTEGER, warn INTEGER, date_join INTEGER, date_verify INTEGER, date_srok INTEGER, global_bale INTEGER, default_bale INTEGER, discord TEXT, age INTEGER, forum TEXT, reason TEXT)")
            await cursor.execute("CREATE TABLE IF NOT EXISTS admins (vkid INTEGER, nick TEXT, dostup INTEGER)")
            await cursor.execute("CREATE TABLE IF NOT EXISTS groups (id INTEGER, name TEXT, max_vig INTEGER, max_warn INTEGER, max_term INTEGER, ids_groups TEXT)")
            await self.bot.db.commit()
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (cfg["bot_vk"]["developer_id"][0],))
            dostup1 = await cursor.fetchone()
            if not dostup1:
                await cursor.execute("INSERT INTO admins (vkid, nick, dostup) VALUES (?, ?, ?)", (cfg["bot_vk"]["developer_id"][0], "Aaron_Castro", 999,))
        await self.bot.db.commit()
        global db
        db = self.bot.db
        vkserver.run_forever()


    @vkserver.on.message(text="/peer")
    async def peer(message: Message):
        await user.account.set_online()
        if message.from_id == cfg["bot_vk"]["developer_id"][0]:
            await message.reply(f"peer_id от бота: {message.peer_id}\npeer_id от аккаунта: {message.peer_id+2}")
        else:
            await message.reply("❗ У вас нет доступа")

    @vkserver.on.message(text="/group_id")
    async def peer(message: Message):
        await user.account.set_online()
        if message.from_id == cfg["bot_vk"]["developer_id"][0]:
            await message.reply(f"{message.group_id}")
        else:
            await message.reply("❗ У вас нет доступа")

    @vkserver.on.message(text=["/dostup", "/dostup <vkid> <dostup> <nick>", "/dostup <vkid> <dostup>", "/dostup <vkid> <nick>", "/dostup <vkid>"])
    async def dostup(message: Message, vkid:str=None, dostup=None, nick:str=None):
        async with db.cursor() as cursor:
            user_id = message.from_id
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
            dostup1 = await cursor.fetchone()
            if not dostup1:
                await message.reply("❗ У вас нет доступа")
            if dostup1[0] >= 2:
                if not vkid:
                    return await message.reply("❗ Изменить доступ - /dostup [*упоминание] [доступ]\n❗ Добавить доступ - /dostup [*упоминание] [доступ] [ник]\n❗ Удалить доступ - /dostup [*упоминание] 0")
                elif not dostup:
                    return await message.reply("❗ Изменить доступ - /dostup [*упоминание] [доступ]\n❗ Добавить доступ - /dostup [*упоминание] [доступ] [ник]\n❗ Удалить доступ - /dostup [*упоминание] 0")
                elif not nick:
                    try:
                        user_id2 = re.findall(r'\[id(\d*)\|.*]', vkid)[0]
                    except:
                        try:
                            await cursor.execute("SELECT vkid FROM admins WHERE nick = ?", (vkid,))
                            user_id2123 = await cursor.fetchone()
                            if not user_id2123:
                                try:
                                    get_user = vkid.partition("https://vk.com/")
                                    get_id = await vkserver.api.utils.resolve_screen_name(screen_name=get_user[2])
                                    user_id2 = get_id.object_id
                                    await message.reply(user_id2)
                                except:
                                    return await message.reply("❗ Изменить доступ - /dostup [*упоминание] [доступ]\n❗ Добавить доступ - /dostup [*упоминание] [доступ] [ник]\n❗ Удалить доступ - /dostup [*упоминание] 0")
                            else:
                                user_id2 = user_id2123[0]
                        except:
                            return await message.reply("❗ Изменить доступ - /dostup [*упоминание] [доступ]\n❗ Добавить доступ - /dostup [*упоминание] [доступ] [ник]\n❗ Удалить доступ - /dostup [*упоминание] 0")
                    await cursor.execute("SELECT nick FROM admins WHERE vkid = ?", (int(user_id2),))
                    nickname = await cursor.fetchone()
                    if int(user_id2) == int(cfg["bot_vk"]["developer_id"][0]):
                        return await message.reply("❗ Вы не можете удалить доступ у разработчика")
                    if int(dostup) == 0:
                        await cursor.execute("DELETE FROM admins WHERE vkid = ?", (user_id2,))
                    else:
                        await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id2,))
                        check = await cursor.fetchone()
                        if check:
                            await cursor.execute("UPDATE admins SET dostup = ? WHERE vkid = ?", (dostup, user_id2,))
                        else:
                            return await message.reply("❌ Пользователя нет в базе данных.")
                    await db.commit()
                    await cursor.execute("SELECT nick FROM admins WHERE vkid = ?", (user_id,))
                    checkMYname = await cursor.fetchone()
                    return await message.reply(f"[id{user_id}|{checkMYname[0]}] изменил доступ у пользователя [id{user_id2}|{nickname[0]}] на {dostup}.")
                elif dostup:
                    try:
                        user_id2 = re.findall(r'\[id(\d*)\|.*]', vkid)[0]
                    except:
                        try:
                            get_user = vkid.partition("https://vk.com/")
                            get_id = await vkserver.api.utils.resolve_screen_name(screen_name=get_user[2])
                            user_id2 = get_id.object_id
                        except:
                            return await message.reply("❗ Изменить доступ - /dostup [*упоминание] [доступ]\n❗ Добавить доступ - /dostup [*упоминание] [доступ] [ник]\n❗ Удалить доступ - /dostup [*упоминание] 0")
                    await cursor.execute("SELECT nick FROM admins WHERE vkid = ?", (user_id2,))
                    check1name = await cursor.fetchone()
                    await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
                    checkmydostup = await cursor.fetchone()
                    await cursor.execute("SELECT dostup FROM admins WHERE nick = ?", (nick,))
                    checknick = await cursor.fetchone()
                    if check1name:
                        return await message.reply("❗ Пользователь уже есть в базе данных.")
                    elif not "_" in nick:
                        return await message.reply("❗ В нике отсутствует нижнее подчеркивание.")
                    elif int(dostup) >= 5:
                        return await message.reply("❗ Максимальный доступ который можно выдать: 4.")
                    elif int(checkmydostup[0]) < int(dostup):
                        return await message.reply("❗ Вы не можете выдать доступ больше чем у вас.")
                    elif checknick:
                        return await message.reply("❗ NickName уже есть в базе данных.")
                    await cursor.execute("SELECT nick FROM admins WHERE vkid = ?", (user_id,))
                    checkMYname22 = await cursor.fetchone()
                    await cursor.execute("INSERT INTO admins (vkid, nick, dostup) VALUES (?, ?, ?)", (user_id2, nick, int(dostup),))
                    await db.commit()
                    return await message.reply(f"[id{user_id}|{checkMYname22[0]}] выдал {dostup} доступ пользователю [id{user_id2}|{nick}].")
            else:
                await message.reply("❗ У вас нет доступа")

    @vkserver.on.message(text="/addbot")
    async def addbot(message: Message):
        async with db.cursor() as cursor:
            await user.account.set_online()
            user_id = message.from_id
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
            dostup1 = await cursor.fetchone()
            if not dostup1:
                await message.reply("❗ У вас нет доступа")
            elif dostup1[0] >= 1:
                users = await user.friends.get_requests()
                msg = await message.reply(f"♻ У бота заявок на добавление: {len(users.items)}\n♻ Бот начал принимать заявки.")
                for i in range(len(users.items)):
                    await user.friends.add(user_id=users.items[i])
                    await asyncio.sleep(1)
                await vkserver.api.messages.edit(peer_id=msg.peer_id, message=f"♻ У бота заявок на добавление: {len(users.items)}\n✅ Бот принял все заявки в друзья.", conversation_message_id=msg.conversation_message_id)
            else:
                await message.reply("❗ У вас нет доступа")

    @vkserver.on.message(text=["/gstats", "/gstats <vkid>"])
    async def gstats(message: Message, vkid=None):
        async with db.cursor() as cursor:
            user_id = message.from_id
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
            dostup1 = await cursor.fetchone()
            if not dostup1:
                await message.reply("❗ У вас нет доступа")
            elif dostup1[0] >= 1:
                msg = message.text
                try:
                    user_id2 = re.findall(r'\[id(\d*)\|.*]', msg)[0]
                    await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (int(user_id2),))
                    checkdostup = await cursor.fetchone()
                    await cursor.execute("SELECT nick FROM admins WHERE vkid = ?", (int(user_id2),))
                    checknick = await cursor.fetchone()
                except:
                    user_id2 = None
                    checkdostup = "None"
                    checknick = "None"
                if not vkid:
                    return await message.reply("❗ Получить информацию о доступе - /gstats [*упоминание/ник]")
                if not checknick:
                    return await message.reply("❗ Пользователя нету в доступах")
                if user_id2:
                    return await message.reply(f"📃 Информация о [id{int(user_id2)}|{checknick[0]}]:\n📃 Уровень доступа: {checkdostup[0]}.")
                elif vkid:
                    await cursor.execute("SELECT dostup FROM admins WHERE nick = ?", (vkid,))
                    checkdostup = await cursor.fetchone()
                    if not checkdostup:
                        return await message.reply("❗ Пользователя нету в доступах")
                    await cursor.execute("SELECT vkid FROM admins WHERE nick = ?", (vkid,))
                    checkvk = await cursor.fetchone()
                    return await message.reply(f"📃 Информация о [id{int(checkvk[0])}|{vkid}]:\n📃 Уровень доступа: {checkdostup[0]}.")
            else:
                await message.reply("❗ У вас нет доступа")

    @vkserver.on.message(text=["/cgroup", "/cgroup <name> <id>", "/cgroup <name>"])
    async def _cgroup(message: Message, name=None, id=None):
        async with db.cursor() as cursor:
            user_id = message.from_id
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
            dostup1 = await cursor.fetchone()
            if not dostup1:
                await message.reply("❗ У вас нет доступа")
            elif dostup1[0] >= 3:
                if not id:
                    return await message.reply("❗ Для создания новой группы - /cgroup [имя группы] [ид группы]")
                if name:
                    user_id2 = re.findall(r'(\d*)', id)[0]
                    if user_id2:
                        await cursor.execute("SELECT name FROM groups WHERE name = ?", (name,))
                        checkForAvalibleGroup = await cursor.fetchone()
                        await cursor.execute("SELECT id FROM groups WHERE id = ?", (int(user_id2),))
                        checkForAvalibleId = await cursor.fetchone()
                        if checkForAvalibleId:
                            return await message.reply("❗ Этот идентификатор группы уже есть в базе данных.")
                        if checkForAvalibleGroup:
                            return await message.reply("❗ Это имя группы уже есть в базе данных.")
                        await cursor.execute("INSERT INTO groups (id, name, ids_groups) VALUES (?, ?, ?)", (int(user_id2), name, None,))
                        await db.commit()
                        return await message.reply(f"✅ Вы успешно создали группу '{name}' с идентификатором {id}.")
                    else:
                        return await message.reply("❗ Для создания новой группы - /cgroup [имя группы] [ид группы]")
                else:
                    return await message.reply("❗ Для создания новой группы - /cgroup [имя группы] [ид группы]")
            else:
                await message.reply("❗ У вас нет доступа")

    @vkserver.on.message(text=["/dgroup", "/dgroup <id>"])
    async def _dgroup(message: Message, id=None):
        async with db.cursor() as cursor:
            user_id = message.from_id
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
            dostup1 = await cursor.fetchone()
            if not dostup1:await message.reply("❗ У вас нет доступа")
            elif dostup1[0] >= 3:
                numbert = re.findall(r'(\d*)', id)[0]
                if not id:return await message.reply("❗ Для удаления группы - /dgroup [ид группы]")
                if numbert:
                    await cursor.execute("SELECT name FROM groups WHERE id = ?", (int(numbert),))
                    checkTF = await cursor.fetchone()
                    if checkTF:
                        keyboard = (
                            Keyboard(inline=True)
                            .add(Callback(label="✅ Подтвердить", payload={"cmd": f"delgroup acces [idvk:{message.from_id}] [param1:{int(numbert)}] [param2:{checkTF[0]}]"}), color=KeyboardButtonColor.NEGATIVE)
                            .add(Callback(label="❌ Отклонить", payload={"cmd": f"delgroup deactive [idvk:{message.from_id}] [param1:{int(numbert)}] [param2:{checkTF[0]}]"}), color=KeyboardButtonColor.POSITIVE)
                        ).get_json()
                        await message.reply(f"♻ Подтвердите действия:\n\n♻ Идентификатор группы: {numbert}\n♻ Имя группы: {checkTF[0]}", keyboard=keyboard)
                    else:return await message.reply("❗ Этой группы нет в базе данных.")
                else:return await message.reply("❗ Для удаления группы - /dgroup [ид группы]")
            else:await message.reply("❗ У вас нет доступа")

    @vkserver.on.chat_message(text=["/addgroupchat", "/addgroupchat <id>"])
    async def addgroupchat(message: Message, id=None):
        async with db.cursor() as cursor:
            user_id = message.from_id
            await cursor.execute("SELECT dostup FROM admins WHERE vkid = ?", (user_id,))
            dostup1 = await cursor.fetchone()
            if not dostup1:await message.reply("❗ У вас нет доступа")
            elif dostup1[0] >= 3:
                chat_id = message.chat_id
                from_id = message.from_id
                id_group = re.findall(r'(\d*)', id)[0]
                if not id:return await message.reply("❗ Для добавления чата в группу - /addgroupchat [ид группы]\n(для добавления чата нужно прописать эту команду в этом-же чате)")
                await cursor.execute("SELECT ids_groups FROM groups WHERE id = ?", (int(id_group),))
                checkTF = await cursor.fetchone()
                if not checkTF:return await message.reply(f"❗ Группы с идентификатором {id_group} не найдено.")
                await cursor.execute("SELECT name FROM groups WHERE id = ?", (int(id_group),))
                checkTD = await cursor.fetchone()
                get_participants = checkTF[0]
                try:
                    participants = json.loads(get_participants)
                except:
                    participants = []
                if chat_id in participants:
                    return await message.reply("❗ Данный чат уже добавлен в группу.")
                participants.append(chat_id)
                await cursor.execute("UPDATE groups SET ids_groups = ? WHERE id = ?", (json.dumps(participants), int(id_group),))
                await db.commit()
                await message.reply(f"✅ Чат добавлен в группу {checkTD[0]}.")
            else:await message.reply("❗ У вас нет доступа")

    @vkserver.on.raw_event(GroupEventType.MESSAGE_EVENT, dataclass=GroupTypes.MessageEvent)
    async def payload_event_handler(event: GroupTypes.MessageEvent):
        async with db.cursor() as cursor:
            if event.object.payload["cmd"].startswith("delgroup acces"):
                payload = event.object.payload["cmd"]
                numbert = re.findall(r'\[idvk:(\d*)]', payload)[0]
                if event.object.user_id == int(numbert):
                    idIntTF = re.findall(r'\[param1:(\d*)]', payload)[0]
                    nameStrTF = re.findall(r'\[param2:(.*)]', payload)[0]
                    if idIntTF:
                        await cursor.execute("DELETE FROM groups WHERE id = ?", (int(idIntTF),))
                        await db.commit()
                        await vkserver.api.messages.edit(peer_id=event.object.peer_id, message=f"✅ Вы успешно удалили группу:\n\n♻ Идентификатор группы: {idIntTF}\n♻ Имя группы: {nameStrTF}", conversation_message_id=event.object.conversation_message_id)
                    else:await vkserver.api.messages.edit(peer_id=event.object.peer_id, message=f"❌ Произошла ошибка, попробуйте ещё раз:\n\n♻ Идентификатор группы: {numbert}\n♻ Имя группы: {nameStrTF}", conversation_message_id=event.object.conversation_message_id)
                else:await vkserver.api.messages.send_message_event_answer(event_id=event.object.event_id, peer_id=event.object.peer_id, user_id=event.object.user_id, event_data=vkjs.dumps({"type": "show_snackbar", "text": "❗ У вас нет доступа к кнопке"}))
            elif event.object.payload["cmd"].startswith("delgroup deactive"):
                payload = event.object.payload["cmd"]
                numbert = re.findall(r'\[idvk:(\d*)]', payload)[0]
                if event.object.user_id == int(numbert):
                    idIntTF = re.findall(r'\[param1:(\d*)]', payload)
                    nameStrTF = re.findall(r'\[param2:(.*)]', payload)
                    await vkserver.api.messages.edit(peer_id=event.object.peer_id, message=f"❌ Вы отклонили удаление группы:\n\n♻ Идентификатор группы: {idIntTF[0]}\n♻ Имя группы: {nameStrTF[0]}", conversation_message_id=event.object.conversation_message_id)
                else:await vkserver.api.messages.send_message_event_answer(event_id=event.object.event_id, peer_id=event.object.peer_id, user_id=event.object.user_id, event_data=vkjs.dumps({"type": "show_snackbar", "text": "❗ У вас нет доступа к кнопке"}))

    # @vkserver.on.message(text="/test")
    # async def _test(message: Message):
    #     await vkserver.api.messages.add_chat_user(chat_id=message.chat_id, user_id=576612413)
        # await user.messages.add_chat_user(chat_id=message.chat_id+2, user_id=576612413)

def setup(bot:commands.Bot):
    bot.add_cog(Vk(bot))
