import nextcord
import os
import asyncio
import aiosqlite
import time
from nextcord.ext import commands, tasks
from nextcord.abc import GuildChannel
from nextcord import Interaction, SlashOption
import datetime, os
import json
from colorama import Fore, Style, init as init_colorama
init_colorama()
cfg = json.load(open(f"{os.path.dirname(os.path.abspath(__file__))}\settings.json"))

COGS_FOLDER = 'modules'

class MyBot(commands.Bot):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.load_extensions()

    def load_extensions(self) -> None:
        print(".---------------------------------------.\n"
              "|                  Коги                 |\n"
              ".---------------------------------------.\n"
              "|  #  |          Ког         |  Статус  |\n"
              "|-----|----------------------|----------|")
        count = 0
        for filename1 in os.listdir(COGS_FOLDER):
            count += 1
            if count <= 9:
                count12 = f"0{count}"
            else:
                count12 = count
            if filename1.endswith('.py'):
                try:
                    self.load_extension(f'modules.{filename1[:-3]}')
                    print(f"| {count12}  |" + " {:<16}     ".format(filename1) + "| " + Fore.GREEN + "Загружен" + Style.RESET_ALL + " |")
                except Exception as e:
                    print(f"| {count12}  |" + " {:<16}     ".format(filename1) + "| " + Fore.RED + "{:<8}".format("Ошибка") + Style.RESET_ALL + " |")
                    with open('err.log', "a") as err:
                        err.write(f"{e}\n")
                        err.close()
        print("'---------------------------------------'")

    async def status_loop(self):
        try:
            await bot.change_presence(status=nextcord.Status.idle, activity=nextcord.Activity(type=nextcord.ActivityType.watching, name="за порядком"))
            await asyncio.sleep(6)
        except:
            pass
        try:
            await bot.change_presence(status=nextcord.Status.idle, activity=nextcord.Activity(type=nextcord.ActivityType.playing, name="Arizona RP Gilbert"))
        except:
            pass
        await asyncio.sleep(6)

    async def on_ready(self):
        t = time.localtime()
        current_time = time.strftime("[%H:%M:%S]", t)
        print(Fore.GREEN + current_time + Style.RESET_ALL + ": Server " + bot.status)
        bot.db = await aiosqlite.connect("Server.db")
        bot.loop.create_task(self.status_loop())
bot = MyBot(command_prefix='!', intents=nextcord.Intents.all())

if __name__ == '__main__':
    bot.run(cfg["bot_discord"]["token"])
